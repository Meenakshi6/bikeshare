This is a demo  project to test Bike Share Model discussed in Cohort 2 IISC AIMLOps curriculum.

